# CozyQuiz „Conquest Max" — statischer Build (für VSC-Claude)

Statische Landing **„Erobere das Feld"**. Client-seitig gerendert, kein Build-Schritt —
`index.html` + `support.js` + `assets/` zusammen ausliefern.

## Inhalt
- `index.html` — komplette Landing (Desktop-Scroll-Experience + Mobile-Layout in einer Datei).
- `support.js` — Runtime, die `index.html` rendert. **Muss neben `index.html` liegen.**
- `assets/` — 6× `av-*.png` (Avatare Desktop-Board), 6× `cat-*.png` (Kategorie-Icons),
  `cozywolf-logo.png`, `og-cover.png` (Share-Bild).
  Pfade extern (`assets/...`), nicht inline.

## Deploy (Vite-Repo `cozywolf-landing`)
1. `index.html` + `support.js` nach `public/` legen (Vite serviert `public/` statisch).
2. **Neu/ergänzen in `public/assets/`:** `cat-10v10.png` (neues 10-von-10-Icon),
   `og-cover.png` (Share-Bild), `cozywolf-logo.png` (fehlt im Repo — dort nur `public/logo.png`;
   entweder Datei kopieren oder in `index.html` `assets/cozywolf-logo.png` → `/logo.png`).
3. `/impressum` + `/datenschutz` laufen über die bestehenden `vercel.json`-Rewrites (React-App).
4. Nach Deploy WhatsApp-/Facebook-Sharing-Cache neu ziehen (Share-Bild).

## ⚠ Diese Seite ist im Repo noch nicht live
`src/App.tsx` rendert aktuell eine ältere Landing. Diese „Conquest Max"-Seite
(Fix-Header, 3D-Brett, Mobile-Scroll-Snap) ist noch nicht deployed. VSC entscheidet:
als statische `public/index.html` einhängen ODER nach React/TSX portieren.

## Stand der Mobile-Optimierung (≤720px)
- **4 Vollbild-Sektionen mit Scroll-Snap**: Hero-Board · So funktioniert's · Fünf Kategorien · Letzte Frage. Jede exakt 100dvh, rastet beim Wischen ein.
- **Inhalt füllt die Höhe** über größere Elemente (keine Totraum-Lücken); Step-Karten & Kategorie-Deck wachsen mit.
- **Einheitliche Headings**: gleiches Pink-Eyebrow + 32px-Titel je Sektion.
- **Header**: 🇩🇪/🇬🇧 SVG-Flaggen (Toggle funktional), „Quiz buchen" einzeilig, Instagram-Icon, Logo allein (Wortmarke ausgeblendet).
- **Footer**: schmale Leiste unten in Sektion 4 — links Logo + „CozyQuiz by cozywolf" (einzeilig), rechts Impressum + Datenschutz.
- **Catch-Frage**: Timer entfernt; beim Antworten klappt der Intro-Block sauber weg, Ergebnis blendet ein — die Frage rutscht nicht mehr unter den Header.
- **Antworten** mobil einspaltig; Bottom-CTA mobil ausgeblendet (Header-CTA reicht).
- **Neues „10 von 10"-Icon** (grüne Poker-Chips) statt des alten Karten-Motivs.

## Quelle
Gebaut aus `CozyQuiz Conquest Max.dc.html`. Änderungen immer in der Quelle machen,
dann diesen Ordner neu erzeugen — **nicht** `index.html` direkt editieren.
